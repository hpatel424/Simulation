#!/usr/bin/env python

print ("Hello World!")

x = input ('Type something and repeat it: ')
print(x)